package mypackage;
import mypackage.HSLColor;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
RegressionTest_it0_livello1.class
})
public class RegressionTest{ }
