package mypackage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
RegressionTest0_it5_livello4.class
})
public class RegressionTest_it5_livello4{ }
